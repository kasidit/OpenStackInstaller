#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#
# run below before launch this script
printf "\nyou are supposed to be running ssh-agent at this point.\n"
# --->ssh-agent /bin/bash
# --> ssh-add
# copy Installer 

#cd $HOME/OPSInstaller/gateway
pwd
echo "copy installer to nodes.. press"
read varkey
scp OPSInstaller.tar vasabi@controller:/home/vasabi/OPSInstaller.tar
scp OPSInstaller.tar vasabi@network:/home/vasabi/OPSInstaller.tar
scp OPSInstaller.tar vasabi@compute:/home/vasabi/OPSInstaller.tar
#
echo "extract installer files on controller.. press"
read varkey
ssh vasabi@controller tar xvf /home/vasabi/OPSInstaller.tar | tee log/extract-controller-current.log
echo "extract installer files on network node.. press"
read varkey
ssh vasabi@network tar xvf /home/vasabi/OPSInstaller.tar | tee log/extract-network-current.log
echo "extract installer files on compute node.. press"
read varkey
ssh vasabi@compute tar xvf /home/vasabi/OPSInstaller.tar | tee log/extract-compute-current.log
#
printf "\n\nNext, you can either (i) run the \"./run-install-all-OPENSTACK.sh\" script or (ii) login to the coltroller, \nthe network, and the compute nodes to run \",./run-verbose.sh\"  script step-by-step.\n"

