#!/bin/bash -x 
#
# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014 vasabilab team 
#
#
# run below before launch this script
printf "\nrun this command under ssh-agent.\n"

#cd $HOME/OPSInstaller/gateway
pwd
#
echo "Install OpenStack"
read varkey
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage00-SUDO-update.sh | tee log/s00-controller.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage01-SUDO-preinstall.sh | tee log/s01.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/network/stage00-SUDO-update.sh | tee log/s00-network.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/network/stage02-SUDO-network-preinstall.sh | tee log/s02.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/compute/stage00-SUDO-update.sh | tee log/s00-compute.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/compute/stage03-SUDO-compute-preinstall.sh | tee log/s03.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage04-SUDO-mysql.sh | tee log/s04.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/network/stage05-SUDO-network-mysql.sh | tee log/s05.log
printf "\n Next? Stages\n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/compute/stage06-SUDO-compute-mysql.sh | tee log/s06.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage07-SUDO-rabbit.sh | tee log/s07.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage08-SUDO-keystone.sh | tee log/s08.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage09-USER-define-keystone-users.sh | tee log/s09.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage10-USER-service-endpoints.sh | tee log/s10.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage11-SUDO-install-pip.sh | tee log/s11.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage12-SUDO-glance.sh | tee log/s12.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage13-USER-glance-endpoint.sh | tee log/s13.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage14-SUDO-restart-glance.sh | tee log/s14.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage15-USER-verify-glance.sh | tee log/s15.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage16-SUDO-control-nova.sh | tee log/s16.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage17-USER-nova-endpoint.sh | tee log/s17.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage18-SUDO-restart-nova.sh | tee log/s18.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage19-USER-verify-nova.sh | tee log/s19.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/compute/stage20-SUDO-nova-comp.sh | tee log/s20.log
printf "\n Next? stages\n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage21-USER-neutron-endpoint.sh | tee log/s21.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage22-SUDO-neutron.sh | tee log/s22.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/network/stage23-SUDO-network-neutron.sh | tee log/s23.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage24-SUDO-reconfig-nova.sh | tee log/s24.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@network sudo ./OPSInstaller/network/stage25-SUDO-set-ml2.sh | tee log/s25.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@compute sudo ./OPSInstaller/compute/stage26-SUDO-neutron-comp.sh | tee log/s26.log
printf "\n Next... reboot the controller, network and compute nodes in order, one at a time\n"
read varkey
#
ssh -t vasabi@controller sudo reboot
echo "--------------"
echo "reboot controller"
for count1 in 1 2 3 4 5 6 7 8 9 10 
do 
    echo "wait 10 seconds..."
    sleep 10
    if ssh vasabi@controller hostname < /dev/null; then
       echo "controller is back"
       echo "wait 10 seconds..."
       sleep 10
       break
    else
       echo "controller is rebooting $count1"
    fi
done 
echo "done rebooting controller!"
#
ssh -t vasabi@network sudo reboot
echo "--------------"
echo "reboot network"
for count1 in 1 2 3 4 5 6 7 8 9 10 
do 
    echo "wait 10 seconds..."
    sleep 10
    if ssh vasabi@network hostname < /dev/null; then
       echo "network is back"
       echo "wait 10 seconds..."
       sleep 10
       break
    else
       echo "network is rebooting $count1"
    fi
done 
echo "done rebooting network!"
#
ssh -t vasabi@compute sudo reboot
echo "--------------"
echo "reboot compute"
for count1 in 1 2 3 4 5 6 7 8 9 10 
do 
    echo "wait 10 seconds..."
    sleep 10
    if ssh vasabi@compute hostname < /dev/null; then
       echo "compute is back"
       echo "network is back"
       sleep 10
       break
    else
       echo "compute is rebooting $count1"
    fi
done 
echo "done rebooting compute!"
echo "--------------"
#
printf "\n\nPress anykey\n"
read varkey
printf "\n Press one more time.. want to make sure all those machines are ready! \n"
read varkey
ssh -t vasabi@network sudo ./OPSInstaller/network/stage26-SUDO-set-ovs.sh | tee log/s26.log
printf "\n Next stages? \n"
read varkey
ssh -t vasabi@controller ./OPSInstaller/controller/stage27-USER-initial-net.sh | tee log/s27.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller ./OPSInstaller/controller/stage28-USER-demo-net.sh | tee log/s28.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage29-SUDOONLY-dashboard.sh | tee log/s29.log
printf "\n Next stages? \n"
read varkey
clear
ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage30-SUDOONLY-apache.sh | tee log/s30.log
printf "\n Next stages? \n"
read varkey
#clear
#ssh -t vasabi@controller sudo ./OPSInstaller/controller/stage31-SUDO-cinder-install.sh | tee log/s31.log
#printf "\n Next stages? \n"
#read varkey
