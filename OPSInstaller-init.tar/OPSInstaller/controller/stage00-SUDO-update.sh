# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# this script or commands below should be called
# prior to openstack installation
#
#!/bin/bash 
#
cd $HOME/OPSInstaller/controller
pwd
printf "You have to \nmodify the files/local-sources.list file before using\nthis script. (Basically, the IP of the ubuntu repo you want to use in this installation).\n"

cp files/hosts /etc/hosts
cp /etc/apt/sources.list /etc/apt/sources.list.saved
cp files/local-sources.list /etc/apt/sources.list
 
 
printf "update\n"

apt-get update
apt-get -y dist-upgrade
