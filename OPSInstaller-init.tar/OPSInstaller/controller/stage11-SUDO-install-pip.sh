# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
echo "Run this script with sudo or as root."
echo -n "1. install pip...press"
read varkey

apt-get -y install python-novaclient
apt-get -y install python-pip

printf "\n2. install pip client for every service...press"
read varkey
pip install python-ceilometerclient
pip install python-cinderclient
pip install python-glanceclient
pip install python-heatclient
pip install python-keystoneclient
pip install python-neutronclient
pip install python-novaclient
pip install python-swiftclient
pip install python-troveclient

