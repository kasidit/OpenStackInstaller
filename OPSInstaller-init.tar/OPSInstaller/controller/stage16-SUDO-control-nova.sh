# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
echo "Run this script with sudo or as root."
echo -n "1. install nova...press"
read varkey

apt-get -y install nova-api nova-cert nova-conductor nova-consoleauth \
  nova-novncproxy nova-scheduler python-novaclient

cp files/nova.conf /etc/nova/nova.conf

rm /var/lib/nova/nova.sqlite

printf "\n2. create nova database tables...press"
read varkey
export MYSQL_PASS=vasabilabMYSQL_PASS
mysql -u root -p$MYSQL_PASS -e "CREATE DATABASE nova;"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'localhost' IDENTIFIED BY 'vasabilabNOVA_DBPASS';"
mysql -u root -p$MYSQL_PASS -e "GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'%' IDENTIFIED BY 'vasabilabNOVA_DBPASS';"

echo "su -s /bin/sh -c \"nova-manage db sync\" nova"
su -s /bin/sh -c "nova-manage db sync" nova

