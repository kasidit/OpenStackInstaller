export OS_USERNAME=demo
export OS_PASSWORD=vasabilabDEMO_PASS
export OS_TENANT_NAME=demo
export OS_AUTH_URL=http://controller:35357/v2.0
