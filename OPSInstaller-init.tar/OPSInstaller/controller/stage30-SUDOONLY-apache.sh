# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
echo "Run this script WITH sudo 'cos apache requires that!"

printf "\n1. restart apache and dashboard...press"
read varkey

cp files/local_settings.py /etc/openstack-dashboard/local_settings.py
cp files/memcached.conf /etc/memcached.conf

service apache2 restart
service memcached restart

echo "You can now make vpn connection and access http://<controller IP>/horizon"
