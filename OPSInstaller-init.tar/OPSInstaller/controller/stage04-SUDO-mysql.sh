# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# Run this with sudo or as root

#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
apt-get -y install python-mysqldb
#
clear
printf "Next mysql installation will ask you to enter root password \n" 
printf "that you defined previously in the install-paramrc.sh file.\n" 
printf "IT IS IMPORTANT THAT YOU ENTER THIS PASSWORD CORRECTLY! \nThe password is.." 
#
echo vasabilabMYSQL_PASS
#
printf "\nplease enter the password above... \n\n" 
read varkey
#
while [ "$varkey" != "vasabilabMYSQL_PASS" ] 
do

  printf "\nNot match! please enter the password again... \n\n" 
  read varkey

done
#
apt-get -y install mysql-server

printf "1. set my.cnf configuration... press any key\n" 
read varkey

cp files/my.cnf /etc/mysql/my.cnf

printf "3. restart mysql & delete anonymous acct... press\n"
read varkey

service mysql restart
mysql_install_db
mysql_secure_installation
#
# set max connection error of mysql to a high value
#
export MYSQL_PASS=vasabilabMYSQL_PASS
mysql -u root -p$MYSQL_PASS -e "SET GLOBAL max_connect_errors=10000;"
