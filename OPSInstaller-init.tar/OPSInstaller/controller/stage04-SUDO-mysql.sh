# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# Run this with sudo or as root

#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
apt-get -y install python-mysqldb
#
clear
printf "Next mysql installation will ask you to enter root password \n" 
printf "that you defined previously in the install-paramrc.sh file.\n" 
printf "IT IS IMPORTANT THAT YOU ENTER THIS PASSWORD CORRECTLY! \nThe password is.." 
#
echo vasabilabMYSQL_PASS
#
printf "\npress any key... \n\n" 
read varkey
#
apt-get -y install mysql-server

printf "1. set my.cnf configuration... press any key\n" 
read varkey

cp files/my.cnf /etc/mysql/my.cnf

printf "3. restart mysql & delete anonymous acct... press\n"
read varkey

service mysql restart
mysql_install_db
mysql_secure_installation
