# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
echo "Run this script as a user."
echo -n "1. create a keystone service...press"
read varkey

export OS_SERVICE_TOKEN=vasabilabADMIN_TOKEN
export OS_SERVICE_ENDPOINT=http://controller:35357/v2.0

keystone service-create --name=keystone --type=identity \
  --description="OpenStack Identity"

printf "\n2. create API endpoint for Identity Service...press"
read varkey
keystone endpoint-create \
  --service-id=$(keystone service-list | awk '/ identity / {print $2}') \
  --publicurl=http://controller:5000/v2.0 \
  --internalurl=http://controller:5000/v2.0 \
  --adminurl=http://controller:35357/v2.0

printf "\n3. Verify keystone Id Service...get a token by user id... press any key"
read varkey
unset OS_SERVICE_TOKEN OS_SERVICE_ENDPOINT

keystone --os-username=admin --os-password=vasabilabADMIN_PASS \
  --os-auth-url=http://controller:35357/v2.0 token-get

printf "\n4. ...get a token by user id and tenant id... press"
read varkey
keystone --os-username=admin --os-password=vasabilabADMIN_PASS \
  --os-tenant-name=admin --os-auth-url=http://controller:35357/v2.0 \
  token-get

printf "\n5. use admin-openrc.sh file and show token .. press"
read varkey
source ./admin-openrc.sh

keystone token-get

printf "\n6. get user role list of the admin user .. press"
read varkey
keystone user-list
keystone user-role-list --user admin --tenant admin


