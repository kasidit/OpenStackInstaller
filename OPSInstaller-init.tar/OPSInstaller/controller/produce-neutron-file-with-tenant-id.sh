# Openstack Installation Script
# Copyright 2014 kasidit chanchio
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
cat files/neutron-part1.conf > files/neutron-gen.conf
echo "nova_admin_tenant_id = $('./find-tenant-id.sh')" >> files/neutron-gen.conf
cat files/neutron-part2.conf >> files/neutron-gen.conf
grep "nova_admin_tenant_id" files/neutron-gen.conf
