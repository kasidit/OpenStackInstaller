# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x
#
printf "(Note: if on vbox, you may want to make a vm snapshot before starting the installation.)\n\n"
case $1 in 
	0) sudo /bin/bash -x ./stage00-SUDO-update.sh 2>&1 | tee log/s00.log; \
		printf "\nnext: ./run-verbose.sh 2\n" ;;
	2) sudo /bin/bash -x ./stage02-SUDO-network-preinstall.sh 2>&1 | tee log/s02.log ; \
		printf "\nnext on compute: cd /home/vasabi/OPSInstaller/compute ; ./run-verbose.sh 0\n" ;;
	5) sudo /bin/bash -x ./stage05-SUDO-network-mysql.sh 2>&1 | tee log/s05.log ; \
		printf "\nSee http://docs.openstack.org/icehouse/install-guide/install/apt/content/basics-database-node.html\n\nnext on compute: cd /home/vasabi/OPSInstaller/compute ; ./run-verbose.sh 6\n"  ;;
	23) sudo /bin/bash -x ./stage23-SUDO-network-neutron.sh 2>&1 | tee log/s23.log ; \
		printf "\nSee http://docs.openstack.org/icehouse/install-guide/install/apt/content/neutron-ml2-network-node.html\n\nnext on controller:  cd /home/vasabi/OPSInstaller/controller ;./run-verbose.sh 24\n"  ;;
	25) sudo /bin/bash -x ./stage25-SUDO-set-ml2.sh 2>&1 | tee log/s25.log ; \
		printf "\nSee http://docs.openstack.org/icehouse/install-guide/install/apt/content/neutron-ml2-network-node.html\n\nnext on compute: cd /home/vasabi/OPSInstaller/compute ; ./run-verbose.sh 26\n"  ;;
	26) sudo /bin/bash -x ./stage26-SUDO-set-ovs.sh 2>&1 | tee log/s26.log ; \
		printf "\nnext on controller: cd /home/vasabi/OPSInstaller/controller; ./run-verbose.sh 27\n"  ;;
	*) printf "\ninvalid parameter value!\n" ;;
esac
